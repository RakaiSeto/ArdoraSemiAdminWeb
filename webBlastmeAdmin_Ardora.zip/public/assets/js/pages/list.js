//[Javascript]



$(function () {
    "use strict";   

		// Slim scrolling
  
	  $('.inner-user-div').slimScroll({
		height: '342px'
	  });
		
	
  }); // End of use strict