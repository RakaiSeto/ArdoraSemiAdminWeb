//[app Javascript]


$(function () {
    "use strict";    
		
	 // chat app scrolling
  
	  $('#chat-app').slimScroll({
		height: '580px'
	  });	
  
	  $('#chat-contact').slimScroll({
		height: '680px'
	  });
	
  }); // End of use strict